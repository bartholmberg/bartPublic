
import cv2
import numpy as np
import open3d as o3d
import open3d.visualization as vis
import copy as cp

import matplotlib.pyplot as plt

import timeit
import threading
import pickle
#The problem statement itself is:
 
#I would like you to create and implement an algorithm that,
# when given a set of points on an infinite plane, will return the complete set of lines of symmetry for those points.
 
#Okay, that's a lot of detail packed into just one sentence, I know. A line of symmetry is defined to be a 
# line such that every point in the input set, when reflected across the line, finds another 
# point in the input set. And we would like the code to find for us the guaranteed-complete set of these lines.
 
#An image that demonstrates the concept of lines of symmetry, where each point in the input set can be thought of as
## a vertex of an input shape, can be found here:
# https://www.onlinemathlearning.com/image-files/xlines-symmetry.png.pagespeed.ic.jD1kSL8EFu.png
#
## Although note that, unlike the image, for this problem statement the inputs are only the vertex points, not the complete shapes, 
# and they can form any arbitrary pattern, 
# not just the shapes shown in the image. 
# Also because we both know that users are very creative in terms of probing the 
## limits of any software that we write, your algorithm should be ready for the points in the input set to be rotated or 
## translated by any arbitrary amount.
 
# I have intentionally left the problem definition open-ended in order to give you the freedom to make choices in how 
# you approach the solution, 
# so feel free to pick whatever programming languages, frameworks, libraries, and even representations 
# for points and lines that you would like - my only ask is that you are able to provide a rationale for your 
# choices and that the core algorithm is written by you.
 

#Please don�t feel like you have to spend many hours creating a perfect solution to this coding challenge, 
#as the intent is for you to be able to complete it within your spare time while still giving me a good 
#sense for how you approach logical and programming problems. Once you have a solution that you�re 
#ready to share, along with an estimate of how many hours it took you to create it, please reach out to me 
#and we can go over it together.
 
#And if you have any questions at all � either about the problem or about Nautilus in general � please 
#don�t hesitate to reach out. I�ll be happy to jump on a call with you at any time.
 
#Thank you, and I look forward to speaking with you again soon!
 
#-- Vadim

# NearLine - given line, and set of [x,y] data points, find nearest distance of each data point
#            to input line, sum all nearest distances and return.  
#            Low numbers means better fit and potential candidate to test symmetry.
#  defined by ( theta - sin(theta) is slope, b - y intercept) 
# input: line, and list of x,y points [ (x0,y0,0) (x1,y1,0).... ] 
#        line0= ( theta0, b0)  , theta ,angle from x axis, in direction of +y.  b is y intercept
#        
# Note:  x , y , shape data may not have zero mean. So subtract mean of x0 in this routine
# #              this is so line scan is still valid with only two parameters theta,b  
  
def NearLine( line, xx ,xmean):
    x=cp.deepcopy(xx) #need to remove xmean later so make dcopy
    N = len(x)
    #
    # we don't care if y is centered , since we have b (y intercept as free parameter)
    # We do care if x is centered, so for now just remove the mean.
    for i in range(0,N):
        x[i][0]=x[i][0]-xmean
    
    theta = line[0]
    #r = [np.cos(theta),  np.sin(theta),0] # make theta relative to x axis
    r = [1,  np.sin(theta),0] # make theta relative to x axis
    #n = [np.cos(theta),  -np.sin(theta),0]
    n = [1,  -np.sin(theta),0]
    n = n/ np.linalg.norm(n)
    r = r / np.linalg.norm(r)

    di =0.0
    #
    # sum up each point and nearest point on line 
    for i in range(N):
        P=np.asarray(x[i])
        Q=np.asarray( [0,-b,0])
        di= np.abs( np.dot( P-Q,n) ) + di
        

    return  (di/N)



if __name__ == "__main__":
    count=0
    grid0 = o3d.geometry.PointCloud()
    #grid=np.random.rand(151*151*10,3)*100 + [100, 200,300]
    grid=np.zeros(shape=(150,3));
    for x in range( -250,251,150):
        for y in range(-250,251,150):
            grid[count]= [x,y,0]
            count=count+1
    grid0.points = o3d.utility.Vector3dVector(grid)
    N=1000
    rvecx=np.random.rand(N,1)*N
    rvecy=np.random.rand(N,1)*N
    rvecx=np.random.normal(0,np.sqrt(N),N)
    rvecy=np.random.normal(0,np.sqrt(N),N)
    square0 = o3d.geometry.PointCloud()
    tstvec=[[ -10, 10, 0],[10, 10, 0], [ -10,-10,0] ,[10, -10, 0]]
    thetar=np.linspace(np.pi*90/180,0,90)
    betar=np.linspace(-20,21,100)
    d=np.zeros(shape=( len(thetar),len(betar)))
    xmean=0
    for i in range(0,len(tstvec)):
        xmean=tstvec[i][0]+xmean
    xmean = xmean/len(tstvec)
    bind=0
    thetaind=0
    #
    #  Generate lines:    y=a*x+b , a = sin(theta)
    #                     for theta [pi/2,0], and b [-20 20]
    #  for each line find the sum( each i, min( tstvec[i] , line) )
    for theta in thetar:
        for b in betar:
            #  set values for testing specific lines
            #theta=np.pi/2
            #b=0
            # small values good, so invert to make good values brighter
            d[thetaind][bind]=1.0/NearLine( (theta,b), tstvec,xmean)
            bind=bind+1
        thetaind=thetaind+1
        bind=0
    d = 255*(d-d.min())/(d.max()-d.min())

    lineImage= d.astype('uint8')
    lineImage = cv2.cvtColor(lineImage, cv2.COLOR_GRAY2BGR)
    plt.imshow( lineImage,extent=[90,0,-20,20] )
    plt.show(block=True)
    plt.draw()
    exit()
    #
    # threshold the d matrix to find feasible symmetry lines
    # Still need to evaluate feasible set of lines to see if actually symmetry lines
    #
    square0.points = o3d.utility.Vector3dVector(tstvec )
    square1=cp.deepcopy(square0 )
    square1.translate( ( 13,15,80))
    o3d.visualization.draw_geometries([grid0], zoom=1/3, front=[0.0, 0.0, 1.0], lookat=[0.0, 1.0, 0.0], up=[0.0, -1, 0])
    xaxi=np.linspace(0,N-1,N)
    #plt.plot(xaxi ,xaxi, xaxi,rvecx,xaxi,rvecy ,rvecx,rvecy)
    plt.scatter(rvecx,rvecy,marker='.')
    plt.show()
   
    exit()