Hi Vadim:

I worked on the 'symmetry lines' problem from 12:30pm to 4:00pm today Friday, and for a ~2.5 hours this afternoon (Saturday April ).  


The current solution produces an image (theta x b).  Where each pixel value is a different lines 'symmetry metric'.  The 'symmetry metric' is the sum of distances of each value of the input set of [x,y] points to nearest point on the line.  
A set of lines is scanned in angle and y offset. 

    #  Generate lines:    y=a*x+b , a = sin(theta)
    #                     for theta [pi/2,0], and b [-20 20] 
 


P =[ (x0,y0,0) (x1,y2,0) ...(xN-1,yN-1,0) ]

The idea with this solution is that the output data should contain all possible symmetry lines (each potential symmetry line tested for symmetry).  Spent some time trying to fine psuedo-inverse solution, but no luck in that direction.

The test case shown is for a square input test case, so output should have two max values in output image (inverted each pixel value). 

Needs further data processing/thresholding to collect actual lines that have min distance.

Note that little testing has been done, and needs more test cases and debugging.  The weird hack of removing the mean of the x dimension of the data is because I wanted only two free parameters theta and y intercept b.

Oh also, didn't end up using open3d in this example yet.  But would keep it in if developing further for testing/debug.

Thanks,

--Bart Holmberg